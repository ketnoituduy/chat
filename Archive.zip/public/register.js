const email = document.getElementById('email')
const password = document.getElementById('password')
const btnReadyAccount = document.getElementById('btnReadyAccount')
btnReadyAccount.addEventListener('click',()=>{
    window.location = 'http://localhost:8000/'
})