const create = document.getElementById('singup')
create.addEventListener('click',()=>{
    window.location = 'localhost:8000/register'
})